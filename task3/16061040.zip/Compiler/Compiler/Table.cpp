#include "pch.h"
#include "Table.h"


Table::Table()
{
}


Table::~Table()
{
}
