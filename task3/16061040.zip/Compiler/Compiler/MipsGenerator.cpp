#include "pch.h"
#include "MipsGenerator.h"


MipsGenerator::MipsGenerator()
{
}


MipsGenerator::~MipsGenerator()
{
}


void MipsGenerator::midcode2asm() {
}

void MipsGenerator::insertaddress() {
}

void MipsGenerator::pushstack() {
}

void MipsGenerator::funcasm() {
}

int MipsGenerator::varaddr() {
	return 1;
}

void MipsGenerator::dataseg() {
}

void MipsGenerator::jmpasm() {
}

void MipsGenerator::printint() {
}

void MipsGenerator::callasm() {
}

void MipsGenerator::setlabasm() {
}

void MipsGenerator::addasm() {
}

void MipsGenerator::subasm() {
}

void MipsGenerator::mulasm() {
}

void MipsGenerator::divasm() {
}

void MipsGenerator::greasm() {
}

void MipsGenerator::geqasm() {
}

void MipsGenerator::lssasm() {
}

void MipsGenerator::leqasm() {
}

void MipsGenerator::eqlasm() {
}

void MipsGenerator::neqasm() {
}

void MipsGenerator::assasm() {
}

void MipsGenerator::aassasm() {
}

void MipsGenerator::assaasm() {
}

void MipsGenerator::scfasm() {
}

void MipsGenerator::prtasm() {
}

void MipsGenerator::fupaasm() {
}

void MipsGenerator::retasm() {
}

void MipsGenerator::paraasm() {
}

void MipsGenerator::jneasm() {
}

void MipsGenerator::intcharasm() {
}

void MipsGenerator::constdefasm() {
}

void MipsGenerator::intcharaasm() {
}
