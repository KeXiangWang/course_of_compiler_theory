#include "pch.h"
#include "Quad.h"


Quad::Quad()
{
}


Quad::~Quad()
{
}

Quantity::Quantity()
{
}

Quantity::~Quantity()
{
}

Caculator::Caculator()
{
}

Caculator::~Caculator()
{
}

Constant::Constant()
{
}

Constant::~Constant()
{
}

FunctionCall::FunctionCall()
{
}

FunctionCall::~FunctionCall()
{
}

Variable::Variable()
{
}

Variable::~Variable()
{
}

Array::Array()
{
}

Array::~Array()
{
}
