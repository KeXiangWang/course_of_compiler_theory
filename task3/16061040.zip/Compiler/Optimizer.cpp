#include "pch.h"
#include "Optimizer.h"


Optimizer::Optimizer()
{
}


Optimizer::~Optimizer()
{
}

void Optimizer::optimize(Quad quad) {

}

void Optimizer::deleteNode() {

}

void Optimizer::dagAnalyze() {

}