#include "pch.h"
#include "Optimizer.h"

void Optimizer::optimize()
{
}

void Optimizer::deleteNode() {

}

void Optimizer::dagAnalyze() {

}